<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Bedroom" tilewidth="16" tileheight="16" tilecount="150" columns="15">
 <image source="mp_house_interiors_tileset_pack/parents_room.png" width="240" height="160"/>
</tileset>
