<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Work Room" tilewidth="16" tileheight="16" tilecount="132" columns="12">
 <image source="mp_house_interiors_tileset_pack/office.png" width="192" height="176"/>
</tileset>
