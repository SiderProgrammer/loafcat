MUCHO PIXELS - CITY STREET TILESET PACK
---------------------------------------

Thank you for downloading this tileset!

The assets contained in this package are arranged in sheets with a 16x16 grid.

This pack is part of the BLUE Pack Series: 
All my blue packs are compatible with each other. You can mix  them to create even more unique locations. The possibilities are almost endless. It can also be used as a standalone tileset.

-------------------------

Licence: https://www.gamedevmarket.net/terms-conditions/#pro-licence

Credits are optional but appreciated :)

-------------------------

Follow Mucho Pixels to catch up on some freebies, ask questions directly to the creator, follow the latest news, suggest new assets or just say "hi!" :)

Twitter: @muchopixels
Facebook: muchopixels
Instagram: muchopixels
Twitch: muchopixels
Youtube: muchopixels

-------------------------

Email: muchopixels@gmail.com