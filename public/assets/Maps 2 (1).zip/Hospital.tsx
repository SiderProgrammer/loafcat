<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Hospital" tilewidth="16" tileheight="16" tilecount="1972" columns="34">
 <image source="mp_hospital_tileset_pack_v1.0/tilemap_all.png" width="544" height="928"/>
</tileset>
