<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Office 2" tilewidth="16" tileheight="16" tilecount="54" columns="9">
 <image source="Rixitic - 2D Sidescroller Office Tileset/tileset_architecture.png" width="144" height="96"/>
</tileset>
