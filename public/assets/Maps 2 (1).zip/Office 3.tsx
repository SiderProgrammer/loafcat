<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Office 3" tilewidth="16" tileheight="16" tilecount="30" columns="10">
 <image source="Rixitic - 2D Sidescroller Office Tileset/tileset_elevator.png" width="160" height="48"/>
</tileset>
